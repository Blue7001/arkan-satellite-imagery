# arkan-satellite-imagery
All the best* imagery I get from capturing weather satellite signal using RTL-SDR Blog V4 w/ SPF5189Z and SatDump

### My desktop wallpaper (Meteor M2-3)
![Meteor M2-3](https://github.com/Blue7001/arkan-satellite-imagery/blob/main/Arkan.png?raw=true)

### Severe tropical cyclone Olga as seen by Meteor M2-4 Satellite on Tue 09 Apr 2024 11:17:57 PM WIB
![Meteor M2-4](https://github.com/Blue7001/arkan-satellite-imagery/blob/main/2024-04-09_07-45_meteor_m2-x_lrpt_137.1%20MHz/MSU-MR/msu_mr_rgb_321_corrected.png?raw=true)

note*: to best of my ability
